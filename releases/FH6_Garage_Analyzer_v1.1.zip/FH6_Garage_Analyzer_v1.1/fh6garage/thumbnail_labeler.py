from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from PySide6.QtCore import QRect, Qt
from PySide6.QtGui import QColor, QFont, QFontMetrics, QImage, QPainter, QPen

from .models import CarName, LiveryRecord, TuningRecord


SavedContentRecord = LiveryRecord | TuningRecord


class ThumbnailLabelError(RuntimeError):
    pass


@dataclass(slots=True)
class ThumbnailWriteResult:
    applied: int = 0
    restored: int = 0
    skipped: int = 0
    failed: int = 0
    messages: list[str] | None = None

    def __post_init__(self) -> None:
        if self.messages is None:
            self.messages = []


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _vehicle_parts(info: CarName) -> tuple[str, str, str]:
    label = (info.label or "").strip()
    year_match = re.match(r"^(\d{4})\s+", label)
    year = year_match.group(1) if year_match else "0000"
    manufacturer = (info.manufacturer or "").strip()
    model = (info.model or "").strip()

    remainder = label[5:].strip() if year_match else label
    if not manufacturer and remainder:
        manufacturer = remainder.split(maxsplit=1)[0]
    if not model:
        if manufacturer and remainder.casefold().startswith(manufacturer.casefold()):
            model = remainder[len(manufacturer):].strip()
        else:
            model = remainder
    return year, manufacturer or "UNKNOWN", model or label or "UNKNOWN VEHICLE"


def _ocr_font(pixel_size: int) -> QFont:
    # Segoe UI is available on supported Windows systems and produces clear,
    # conventional glyphs for Windows text extraction (Win+Shift+T).  Arial is
    # the portable fallback used by Qt when Segoe UI is unavailable.
    font = QFont("Segoe UI Variable")
    font.setStyleHint(QFont.StyleHint.SansSerif)
    font.setWeight(QFont.Weight.Bold)
    font.setPixelSize(pixel_size)
    return font


def _fit_font(text: str, max_width: int, maximum: int, minimum: int) -> QFont:
    for size in range(maximum, minimum - 1, -1):
        font = _ocr_font(size)
        if QFontMetrics(font).horizontalAdvance(text) <= max_width:
            return font
    font = _ocr_font(minimum)
    stretch = max(50, int(100 * max_width / max(1, QFontMetrics(font).horizontalAdvance(text))))
    font.setStretch(stretch)
    return font


def _draw_outlined_text(
    painter: QPainter,
    rect: QRect,
    text: str,
    font: QFont,
    alignment: Qt.AlignmentFlag,
) -> None:
    painter.setFont(font)
    painter.setPen(QPen(QColor(255, 255, 255, 245), 1))
    for dx, dy in (
        (-2, -2), (0, -2), (2, -2),
        (-2, 0),            (2, 0),
        (-2, 2),  (0, 2),   (2, 2),
    ):
        painter.drawText(rect.translated(dx, dy), int(alignment), text)
    painter.setPen(QPen(QColor(12, 14, 18, 255), 1))
    painter.drawText(rect, int(alignment), text)


def label_image(
    source: Path,
    destination: Path,
    info: CarName,
    *,
    show_vehicle_info: bool = True,
    show_red_x: bool = False,
) -> None:
    image = QImage(str(source))
    if image.isNull():
        raise ThumbnailLabelError("썸네일 이미지를 읽을 수 없습니다.")
    if image.width() < 320 or image.height() < 180:
        raise ThumbnailLabelError(
            f"지원하지 않는 해상도: {image.width()}×{image.height()} (최소: 320×180)"
        )

    year, manufacturer, model = _vehicle_parts(info)
    model = model.upper()
    manufacturer = manufacturer.upper()

    painter = QPainter(image)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

    sx = image.width() / 670.0
    sy = image.height() / 376.0
    scale = min(sx, sy)

    def rect(x: int, y: int, width: int, height: int) -> QRect:
        return QRect(
            round(x * sx), round(y * sy),
            round(width * sx), round(height * sy),
        )

    model_font = _fit_font(model, round(658 * sx), maximum=max(12, round(23 * scale)), minimum=max(9, round(16 * scale)))
    maker_font = _fit_font(manufacturer, round(658 * sx), maximum=max(12, round(23 * scale)), minimum=max(9, round(16 * scale)))
    year_font = _fit_font(year, round(205 * sx), maximum=max(16, round(31 * scale)), minimum=max(12, round(24 * scale)))

    if show_vehicle_info:
        _draw_outlined_text(
            painter, rect(6, 1, 658, 29), model, model_font,
            Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
        )
        _draw_outlined_text(
            painter, rect(5, 311, 205, 36), year, year_font,
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
        )
        _draw_outlined_text(
            painter, rect(6, 347, 658, 28), manufacturer, maker_font,
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom,
        )

    if show_red_x:
        border_width = max(5, round(8 * scale))
        border_inset = max(1, (border_width + 1) // 2)
        painter.setPen(
            QPen(
                QColor(220, 35, 48, 255),
                border_width,
                Qt.PenStyle.SolidLine,
                Qt.PenCapStyle.SquareCap,
                Qt.PenJoinStyle.MiterJoin,
            )
        )
        painter.drawRect(
            border_inset,
            border_inset,
            max(1, image.width() - (border_inset * 2) - 1),
            max(1, image.height() - (border_inset * 2) - 1),
        )

        center_x = round(638 * sx)
        center_y = round(188 * sy)
        radius = max(9, round(17 * scale))
        painter.setPen(QPen(QColor(255, 255, 255, 245), max(4, round(7 * scale)), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawLine(center_x - radius, center_y - radius, center_x + radius, center_y + radius)
        painter.drawLine(center_x + radius, center_y - radius, center_x - radius, center_y + radius)
        painter.setPen(QPen(QColor(220, 35, 48, 255), max(2, round(4 * scale)), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawLine(center_x - radius, center_y - radius, center_x + radius, center_y + radius)
        painter.drawLine(center_x + radius, center_y - radius, center_x - radius, center_y + radius)
    painter.end()

    destination.parent.mkdir(parents=True, exist_ok=True)
    image_format = "PNG" if destination.suffix.casefold() == ".png" else "WEBP"
    quality = -1 if image_format == "PNG" else 100
    if not image.save(str(destination), image_format, quality):
        raise ThumbnailLabelError(f"{image_format} 저장에 실패했습니다.")


def _backup_dir(backup_root: Path, record: SavedContentRecord) -> Path:
    return backup_root / record.container_name


def apply_labels(
    records: list[SavedContentRecord],
    car_lookup,
    backup_root: Path,
    red_x_lookup=None,
) -> ThumbnailWriteResult:
    if red_x_lookup is not None:
        combined = ThumbnailWriteResult()
        for record in records:
            outcome = apply_visual_state(
                [record],
                car_lookup,
                backup_root,
                vehicle_info=True,
                red_x=bool(red_x_lookup(record)),
            )
            combined.applied += outcome.applied
            combined.skipped += outcome.skipped
            combined.failed += outcome.failed
            combined.messages.extend(outcome.messages)
        return combined
    return apply_visual_state(
        records,
        car_lookup,
        backup_root,
        vehicle_info=True,
    )


def apply_visual_state(
    records: list[SavedContentRecord],
    car_lookup,
    backup_root: Path,
    *,
    vehicle_info: bool | None = None,
    red_x: bool | None = None,
) -> ThumbnailWriteResult:
    result = ThumbnailWriteResult()
    backup_root.mkdir(parents=True, exist_ok=True)

    for record in records:
        source = record.thumbnail_path
        if source is None or not source.is_file() or record.car_id is None:
            result.skipped += 1
            continue
        backup_dir = _backup_dir(backup_root, record)
        backup = backup_dir / source.name
        manifest = backup_dir / "backup.json"
        try:
            backup_dir.mkdir(parents=True, exist_ok=True)
            if not backup.exists():
                shutil.copy2(source, backup)
                payload = {
                    "schema": 2,
                    "container_name": record.container_name,
                    "original_path": str(source),
                    "car_id": record.car_id,
                    "original_sha256": _sha256(backup),
                    "backed_up_at": datetime.now(timezone.utc).isoformat(),
                    "vehicle_info_applied": False,
                    "red_x_applied": False,
                }
            elif manifest.is_file():
                payload = json.loads(manifest.read_text(encoding="utf-8"))
                if str(payload.get("original_path", "")) != str(source):
                    raise ThumbnailLabelError(
                        "같은 컨테이너명의 다른 원본 백업이 이미 존재합니다."
                    )
                if "vehicle_info_applied" not in payload:
                    # v0.1.34 and older only modified thumbnails by adding
                    # vehicle text, so a difference from the pristine backup
                    # is the backward-compatible indication that it is active.
                    payload["vehicle_info_applied"] = _sha256(source) != _sha256(backup)
                payload.setdefault("red_x_applied", False)
                payload["schema"] = 2
            else:
                raise ThumbnailLabelError("백업 이미지의 manifest가 없습니다.")

            if vehicle_info is not None:
                payload["vehicle_info_applied"] = bool(vehicle_info)
            if red_x is not None:
                payload["red_x_applied"] = bool(red_x)

            with tempfile.NamedTemporaryFile(
                prefix="fh6_thumb_", suffix=source.suffix, delete=False,
                dir=source.parent,
            ) as temp_stream:
                temp_path = Path(temp_stream.name)
            try:
                label_image(
                    backup,
                    temp_path,
                    car_lookup(record.car_id),
                    show_vehicle_info=bool(payload["vehicle_info_applied"]),
                    show_red_x=bool(payload["red_x_applied"]),
                )
                os.replace(temp_path, source)
            finally:
                temp_path.unlink(missing_ok=True)
            manifest.write_text(
                json.dumps(payload, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            result.applied += 1
        except (OSError, ValueError, ThumbnailLabelError) as exc:
            result.failed += 1
            result.messages.append(f"{record.container_name}: {exc}")
    return result


def restore_originals(
    records: list[SavedContentRecord],
    backup_root: Path,
) -> ThumbnailWriteResult:
    result = ThumbnailWriteResult()
    for record in records:
        destination = record.thumbnail_path
        backup_dir = _backup_dir(backup_root, record)
        backup = backup_dir / destination.name if destination is not None else backup_dir / "missing"
        manifest = backup_dir / "backup.json"
        if destination is None or not backup.is_file() or not manifest.is_file():
            result.skipped += 1
            continue
        try:
            payload = json.loads(manifest.read_text(encoding="utf-8"))
            if str(payload.get("original_path", "")) != str(destination):
                raise ThumbnailLabelError("백업 원본 경로와 현재 대상 경로가 다릅니다.")
            expected = str(payload.get("original_sha256", ""))
            if not expected or _sha256(backup) != expected:
                raise ThumbnailLabelError("백업 SHA-256 검증 실패")
            with tempfile.NamedTemporaryFile(
                prefix="fh6_restore_", suffix=destination.suffix, delete=False,
                dir=destination.parent,
            ) as temp_stream:
                temp_path = Path(temp_stream.name)
            try:
                shutil.copy2(backup, temp_path)
                os.replace(temp_path, destination)
            finally:
                temp_path.unlink(missing_ok=True)
            payload["schema"] = 2
            payload["vehicle_info_applied"] = False
            payload["red_x_applied"] = False
            manifest.write_text(
                json.dumps(payload, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            result.restored += 1
        except (OSError, ValueError, json.JSONDecodeError, ThumbnailLabelError) as exc:
            result.failed += 1
            result.messages.append(f"{record.container_name}: {exc}")
    return result
